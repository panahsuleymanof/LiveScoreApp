//
//  LoggedUser+CoreDataClass.swift
//  LiveScoreApp
//
//  Created by Panah Suleymanli on 23.06.24.
//
//

import Foundation
import CoreData

@objc(LoggedUser)
public class LoggedUser: NSManagedObject {

}
