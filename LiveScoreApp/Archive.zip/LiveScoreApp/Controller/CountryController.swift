//
//  CountryController.swift
//  LiveScoreApp
//
//  Created by Panah Suleymanli on 19.06.24.
//

import UIKit

class CountryController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.lightGray]
    }
    
    
}
