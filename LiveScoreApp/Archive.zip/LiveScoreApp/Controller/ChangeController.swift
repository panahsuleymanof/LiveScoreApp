//
//  ChangeController.swift
//  LiveScoreApp
//
//  Created by Panah Suleymanli on 23.06.24.
//

import UIKit

class ChangeController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
