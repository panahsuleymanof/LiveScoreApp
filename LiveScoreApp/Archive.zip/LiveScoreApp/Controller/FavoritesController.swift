//
//  FavoritesController.swift
//  LiveScoreApp
//
//  Created by Panah Suleymanli on 14.06.24.
//

import UIKit

class FavoritesController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
