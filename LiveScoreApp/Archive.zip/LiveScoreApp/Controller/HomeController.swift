//
//  HomeController.swift
//  LiveScoreApp
//
//  Created by Panah Suleymanli on 08.06.24.
//

import UIKit

class HomeController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var countries = [Country]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseFootballFile()
        tableView.register(UINib(nibName: "\(LiveCell.self)", bundle: nil), forCellReuseIdentifier: "\(LiveCell.self)")
    }
    
    func parseFootballFile() {
        if let file = Bundle.main.url(forResource: "Football", withExtension: "json") {
            do {
                let data = try Data(contentsOf: file)
                countries = try JSONDecoder().decode([Country].self, from: data)
                print("football: \(countries)")
            } catch {
                showError(message: error.localizedDescription)
            }
        }
    }
    
    func showError(message: String) {
        let alert = UIAlertController(title: "Error",
                                      message: message,
                                      preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default)
        alert.addAction(ok)
        present(alert, animated: true)
    }
    
}

extension HomeController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        countries[0].leagues.count * countries.count
        10
    }
    
    /*
     {
         "name": "Spain",
         "leagues": [
             {
                 "name": "La Liga",
                 "teams": [
                     "Real Madrid",
                     "Barcelona",
                     "Atletico Madrid",
                     "Sevilla FC"
                 ],
                 "liveMatch": {
                     "homeTeam": "Real Madrid",
                     "awayTeam": "Barcelona",
                     "homeScore": "1",
                     "awayScore": "1"
                 }
             },
     */
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "\(LiveCell.self)", for: indexPath) as! LiveCell
        for league in countries[indexPath.row].leagues {
            cell.configureCell(data: league.liveMatch)
        }
        
//        for league in countries[indexPath.row].leagues {
//            cell.configureCell(data: league.liveMatch)
//        }
      //   cell.configureCell(data: countries[indexPath.row].leagues[indexPath.item].liveMatch)
                cell.configureCountryandLeague(country: countries[indexPath.row].name, league: countries[indexPath.row].leagues[1].name)
        cell.navigationCallback = {
            let vc = self.storyboard?.instantiateViewController(identifier: "\(CountryController.self)") as! CountryController
            vc.title = self.countries[indexPath.row].name
            self.navigationController?.show(vc, sender: nil)
        }
        return cell
    }
}

extension HomeController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        120
    }
}
